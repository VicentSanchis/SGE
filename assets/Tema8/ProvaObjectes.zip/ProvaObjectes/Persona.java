import java.io.*;

public class Persona implements Serializable {
  private long serialVersionUID = 1L;
  private String nom;
  private String malnom;
  
  public Persona (String n, String m) {
    this.nom = n;
    this.malnom = m;
  }
  
  public void save (String path) {
    try {
      // Creating stream and writing the object
      FileOutputStream fout = new FileOutputStream(path + "dadesPersones.dat");
      ObjectOutputStream out = new ObjectOutputStream(fout);
      out.writeObject(this);
      out.flush();
      out.close();
      System.out.println("Object stored successfully");
    }
    catch (Exception e) {
      System.out.println(e);
      e.printStackTrace();
    } //<>// //<>//
  }
  
  public static Persona readFromFile (String path) {
    try {
      FileInputStream fin = new FileInputStream(path + "dadesPersones.dat");
      ObjectInputStream oin = new ObjectInputStream(fin);
      Persona p = (Persona)oin.readObject();
      oin.close();
      return p;
    }
    catch (Exception e) {
      System.out.println(e);
      e.printStackTrace();
    }
    return null;
  }
  
  public void saluda () {
    System.out.println("Hola soc " + this.nom + " " + this.malnom);
  }
}
